#!/usr/bin/python

import sys 

sys.path.insert(0, '/usr/lib/python2.7/bridge/') 

from bridgeclient import BridgeClient as bridgeclient

import _mysql
import time

value = bridgeclient() 

DataBase_server = '127.0.0.1' 
DataBase_user = 'root'
Database_password = 'myjamaicaboys237'
Database_name = 'Time'


def DleteData():

	connect.query ( 'delete from dt' )




def who():
	person = "UNKOWN"

	return str(person)


def GetTime():

	currentTime_Date = time.strftime("%c");

	return str(currentTime_Date)

try:


	connect = _mysql.connect(DataBase_server,DataBase_user,Database_password,Database_name) 

	print "connected to database"

	DleteData()


	print value.get('State_of_button')

	if (value.get('State_of_button') == "1"):

		DoorBell_State = value.get('State_of_button') 
		
		print "found data" 

		sql_q = "INSERT INTO Log(dt,who) VALUES (" + "'" +GetTime()+ "'" +"," + "'"+ who()+"'" + ")"

		connect.query ( sql_q )

		print "data Inserted"

        

	elif (value.get('State_of_button') == None):

		print "no data but inserting a zero"



		sql_q = "INSERT INTO Log(dt,who) VALUES (" + "'" + GetTime()+ "'" +"," + "'"+ who()+"'" + ")"

		connect.query ( sql_q )


		print "data Inserted"

	else: 

		print "Invaled data"


except  _mysql.Error, e:

	print "DataBase error"

	print "Error %d: %s" % (e.args[0], e.args[1])

	sys.exit(1)