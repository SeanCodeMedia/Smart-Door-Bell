
<?php  
	
 
 // sql command is mysql -u root -p

$DBServer = '127.0.0.1'; 
$DBUser   = 'root';
$DBPass   = 'myjamaicaboys237';
$DBName   = 'smartdoor';  
$conn = mysql_connect($DBServer, $DBUser, $DBPass) or die ("Cannot Connect to database");
mysql_select_db($DBName) or die ("cannot select DB"); 
$sql = "select * from Door";
$result = mysql_query($sql); 
$json = array(); 
$count=0;
if(mysql_num_rows($result)){ 
while($row=mysql_fetch_row($result)) { 
$count = $count+1; 
$json["Door".$count]=$row; 
} 
}

echo json_encode($json);  



  if (isset($_GET)){ 
	
	  $DoorBell_State  =$_GET["value"]; 
	  
	  mysql_query("UPDATE Door SET State = $DoorBell_State WHERE id = 1");
	 
	  
	  echo $DoorBell_State;
	  
	  }
	  
	  "<br>"; 
	  
	  "<br>"; 
	  
	//  echo "Date and Time"; 
	 
	 echo $masterData;
   
	
?>

