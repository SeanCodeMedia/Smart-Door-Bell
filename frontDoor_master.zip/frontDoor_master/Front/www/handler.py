#!/usr/bin/python

import sys 

sys.path.insert(0, '/usr/lib/python2.7/bridge/') 

from bridgeclient import BridgeClient as bridgeclient

import _mysql

value = bridgeclient() 

DataBase_server = '127.0.0.1' 
DataBase_user = 'root'
Database_password = 'myjamaicaboys237'
Database_name = 'smartdoor'

try: 
	connect = _mysql.connect(DataBase_server,DataBase_user,Database_password,Database_name) 

	print "connected to database"

	print value.get('State_of_button')

	if (value.get('State_of_button') == '1' or value.get('State_of_button') == '0'  ):

		DoorBell_State = value.get('State_of_button') 
		
		print "found data" 


		connect.query("UPDATE Door SET State =" +DoorBell_State +" WHERE id = 1")

		print "database updated"

	

	elif (value.get('State_of_button') == None):

		print "no data but inserting a zero"

		connect.query("UPDATE Door SET State = 0 WHERE id = 1")

		print "database updated"

	else: 

		print "Invaled data"


except  _mysql.Error, e:

	print "DataBase error"

	print "Error %d: %s" % (e.args[0], e.args[1])

	sys.exit(1)