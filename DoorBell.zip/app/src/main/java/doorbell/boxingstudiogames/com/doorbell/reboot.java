package doorbell.boxingstudiogames.com.doorbell;


import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class reboot extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {


        try {

            Intent rebootup  = new Intent(context,dataService.class);

            context.startService(rebootup);

            Toast.makeText(context,"ReStarting service",Toast.LENGTH_LONG).show();



        } catch (Exception e) {


            Toast.makeText(context," Cannot reStarting service",Toast.LENGTH_LONG).show();

        }




    }



}
