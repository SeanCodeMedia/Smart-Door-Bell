package doorbell.boxingstudiogames.com.doorbell;


import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

import java.lang.reflect.Array;


/**
 * Created by Sean on 6/30/2015.
 *
 *
 */
public class Settings extends ActionBarActivity {


    String TAG = getPackageName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.settings_main2);




    }


    public void check(View view){

        boolean checked = ((CheckBox) view).isChecked();

        if(checked){

            try {

                Intent stopService = new Intent(this,dataService.class);

                stopService(stopService);


                Toast.makeText(this,"Door Bell disabled",Toast.LENGTH_LONG).show();


            } catch ( Exception e) {

                Toast.makeText(this,"cannot disable doorbell",Toast.LENGTH_LONG).show();


            }





        }

        else if (!checked){
            
           try {

               Intent startUp_Service = new Intent(this,dataService.class);

               startService(startUp_Service);


               Toast.makeText(this,"Door Bell enable",Toast.LENGTH_LONG).show();


           } catch (Exception e) {


               Toast.makeText(this, "cannot start Door Bell !",Toast.LENGTH_LONG).show();

           }


        }



    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
     //   getMenuInflater().inflate(R.menu.menu2, menu);

        return true;
    }





}





