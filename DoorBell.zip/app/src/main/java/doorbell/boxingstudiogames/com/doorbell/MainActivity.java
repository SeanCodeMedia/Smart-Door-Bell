package doorbell.boxingstudiogames.com.doorbell;


import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends ActionBarActivity {

    String url = "http://192.168.1.8/sd/logger.php";

    String JsonData;


    ArrayList <String> LoggerList = new ArrayList<String>();



    String TAG = getPackageName();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);


        try {


            Intent  intent = new Intent(this, dataService.class);

            startService(intent);



        } catch (Exception e) {


            Toast.makeText(this, "cannot start service",Toast.LENGTH_LONG).show();

        }


        ListView H_list = (ListView) findViewById(R.id.listView);

        final ArrayAdapter arrayAdapter = new ArrayAdapter<String>(this, R.layout.list_theme, LoggerList);



        try {

        H_list.post(new Runnable() {
            @Override
            public void run() {




                final RequestQueue requestQueue2 = Volley.newRequestQueue(getApplicationContext());


                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,

                        new Response.Listener<JSONObject>() {

                            @Override
                            public void onResponse(JSONObject jsonobject) {

                                try {



                                    for ( int i = 1; i < jsonobject.length(); i++) {

                                        String key = "Log" + i;

                                        JsonData = jsonobject.getJSONArray(key).getString(1).toString();


                                        arrayAdapter.add(JsonData);




                                    }


                                } catch (JSONException e) {

                                    Log.d(TAG, "Fail to download data from server");


                                }


                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError volleyError) {

                        Log.d(TAG,  volleyError.toString());




                    }
                });


                requestQueue2.add(jsonObjectRequest);


            }




        });


        H_list.setAdapter(arrayAdapter);

        } catch (Exception e) {

            Log.d(TAG,"cannot populate list");


        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);



        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();



        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            Intent intent2 = new Intent(getApplicationContext(),Settings.class);
            startActivity(intent2);


            Log.d(TAG,"Pressed");



            return true;
        }

        return super.onOptionsItemSelected(item);
    }



}
