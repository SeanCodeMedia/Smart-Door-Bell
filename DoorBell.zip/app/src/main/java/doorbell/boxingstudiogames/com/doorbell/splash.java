package doorbell.boxingstudiogames.com.doorbell;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;

/**
 * Created by Sean on 6/30/2015.
 */
public class splash extends Activity{

    String TAG = getPackageName();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.splash_layout);

      final Intent splashIntent = new Intent(this,MainActivity.class);


        final Runnable runnable = new Runnable() {
            @Override
            public void run() {

                try{


                    Log.d(TAG,"----------splash screen--------------");


                    Thread.sleep(2000);

                    splashIntent.addFlags(splashIntent.FLAG_ACTIVITY_CLEAR_TOP);

                    Log.d(TAG,"----------clearing backstack--------------");



                    startActivity(splashIntent);

                }catch (Exception e) {



                    Log.d(TAG,"Message = "+e.getMessage());

                }




            }
        };


        Thread  thread = new Thread(runnable);

        thread.start();



    }
}
