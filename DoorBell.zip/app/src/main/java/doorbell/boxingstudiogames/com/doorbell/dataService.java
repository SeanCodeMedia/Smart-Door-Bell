package doorbell.boxingstudiogames.com.doorbell;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.IBinder;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class dataService extends Service {


    final String TAG = getPackageName();

    String JsonData;
    int value;
    boolean runOnce = false;

    //String  http://poeavedoorbell.cf/ http://www.doorbellave.net63.net/

    String url = "http://192.168.1.8/sd/index.php";


    boolean downloadData = true;


  ///  public dataService() { }



    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Toast.makeText(this,"Starting service",Toast.LENGTH_LONG).show();


        final RequestQueue requestQueue = Volley.newRequestQueue(getApplication());



        final Runnable runnable = new Runnable() {


            @Override
            public void run() {
             // update service every one second



            while (downloadData == true) {

                try {

                    Log.d(TAG, "Back to top");


                    long futureTimed = System.currentTimeMillis() + 1000;

                    while (futureTimed > System.currentTimeMillis()) {

                        synchronized (this) {

                            wait(futureTimed - System.currentTimeMillis());


                            try {
                                // what we need to download


                                JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null,



                                        new Response.Listener<JSONObject>() {

                                            @Override
                                            public void onResponse(JSONObject jsonobject) {

                                                try {


                                                    JsonData = jsonobject.getJSONArray("Door1").getString(1).toString();

                                                    value = Integer.parseInt(JsonData);

                                                    Log.d(TAG,JsonData);



                                                    if (value == 1) {


                                                        Log.d(TAG, "doorBell on");

                                                       sendNotification();

                                                        // call history class



                                                    } else if (value == 0) {


                                                        Log.d(TAG, "doorBell off");

                                                        runOnce = false;




                                                    }


                                                } catch (JSONException e) {

                                                    Log.d(TAG, "Fail to download data from server");


                                                }


                                            }
                                        }, new Response.ErrorListener() {
                                    @Override
                                    public void onErrorResponse(VolleyError volleyError) {

                                        Log.d(TAG,  volleyError.toString());




                                    }
                                });


                                requestQueue.add(jsonObjectRequest);


                            } catch (Exception e) {


                                Log.d(TAG, "Error" + e.getMessage());


                            }



                        }


                    }

                } catch (Exception e) {

                    Log.e (TAG,e.getMessage());

                }

            }



               }
        };


        Thread data = new Thread(runnable);

        data.start();


        return START_STICKY;
    }






        @Override
    public void onDestroy() {
        super.onDestroy();
    }



    @Override
    public IBinder onBind(Intent intent) {


        return null;
    }


    void sendNotification() {


     if (runOnce == false) {

            PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, new Intent(), 0);

            NotificationCompat.Builder notify = new NotificationCompat.Builder(this);


            notify.setContentTitle("Door Bell !");

            notify.setTicker("Ding Dong !");

            notify.setContentText("Some one is at the door");

            notify.setSmallIcon(R.drawable.samll_icon);

            notify.setSound(Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.sound));

            notify.setDefaults(Notification.DEFAULT_LIGHTS | Notification.DEFAULT_VIBRATE);


            notify.setContentIntent(pendingIntent);
            notify.setAutoCancel(true);
            ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(1, notify.build());


            runOnce = true;


     }


    }


    }
